#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctype.h>


void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
      
     char buf[100];
     int sockfd, newsockfd, port_number;
     socklen_t clilen;
     char buffer[512];
     struct sockaddr_in server_addr, client_addr;
     int n;
     if (argc < 2) {
         fprintf(stderr,"ERROR, no port is being provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);   //TCP
     if (sockfd < 0) 
        error("ERROR in opening the socket");
     bzero((char *) &server_addr, sizeof(server_addr));
     port_number = atoi(argv[1]);
     server_addr.sin_family = AF_INET;
     server_addr.sin_addr.s_addr = INADDR_ANY;
     server_addr.sin_port = htons(port_number);
     if (bind(sockfd, (struct sockaddr *) &server_addr,
              sizeof(server_addr)) < 0) 
              error("ERROR on binding occurs.\n");
     listen(sockfd,5);
     clilen = sizeof(client_addr);
     newsockfd = accept(sockfd, 
                 (struct sockaddr *) &client_addr, 
                 &clilen);
     if (newsockfd < 0) 
          error("ERROR while accepting .\n");


    printf("Receiver\n");
   
   int window_size;
   printf("Enter window size for the Receiver: - \n");
   scanf("%d",&window_size);

   sprintf(buf,"%d",window_size);
   write(newsockfd,&buf,100);
   
   for(int i=1;i<=50;i+=window_size)			//As we need to send 50 packets over the network
   {
      int num=rand()%window_size;
      int val=i+num;
     for(int j=i;j<i+window_size;j++)
     {
      if(j==val)
      printf("Error in the packet number :-  %d\n",val);
      else
      printf("Received the packet of number:- %d\n",j);
     }
     
     
     printf("\t*<---- Sending a N-ACK for the packet with number :- %d\n",val);
     sprintf(buf,"%d",val);
     write(newsockfd,&buf,100);
     
    
     printf("Received packet of number :-  %d\n",val);
   }
     close(newsockfd);  //closing the socket newsockfd
     close(sockfd);		//closing the socket sockfd
     return 0; 
}

