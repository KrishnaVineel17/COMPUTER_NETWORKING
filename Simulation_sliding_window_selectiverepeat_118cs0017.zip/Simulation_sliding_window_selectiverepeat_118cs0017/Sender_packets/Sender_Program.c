#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h> 
#include<ctype.h>
#include<arpa/inet.h>


void error(const char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    // Trying to Establish a connection
    int sockfd, port_number, n;
    struct sockaddr_in server_addr;
    struct hostent *server;
    char buf[100];

    char buffer[512];
    if (argc < 3)
    {
       fprintf(stderr,"usage :  %s host_name port_number\n", argv[0]);
       exit(0);
    }
    port_number = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);  //TCP 
    if (sockfd < 0) 
        error("ERROR in opening the  socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, there's no such host\n");
        exit(0);
    }
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&server_addr.sin_addr.s_addr,
         server->h_length);
    server_addr.sin_port = htons(port_number);
    if (connect(sockfd,(struct sockaddr *) &server_addr,sizeof(server_addr)) < 0) 
        error("ERROR in connecting. Please check again");
  
        bzero(buffer,512);
    

    printf("Sender\n");
    
     int window_size;
    printf("Enter the Window Size for the Sender :-  \n");
    scanf("%d",&window_size);
    
     int k=read(sockfd,&buf,100);
       if(k==-1)
        {
         printf("Error in receiving\n");
         exit(1);
        }
     
    int window_size_rec=atoi(buf);
    
    for(int i=1;i<=50;i+=window_size)		//As we deal with 50 packets over the network
    {
       for(int j=i;j<i+window_size;j++)
          printf("Send Packet number :%d\n",j);

      int lostack=(window_size/window_size_rec);
      while(lostack--)
      { 
       k=read(sockfd,&buf,100);
       if(k==-1)
        {
         printf("Error in receiving the packets/frames \n");
         exit(1);
        }
      
      printf("Received N-ACK for the  Packet number :-  %s\n",buf);
      printf("Resending the packet of number :-  %s\n",buf);

      }
       
    }
    close(sockfd);   	//closing the socket Sockfd
    return 0;
}

